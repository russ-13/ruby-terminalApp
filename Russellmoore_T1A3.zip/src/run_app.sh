#!/bin/bash

bundle install

ruby main.rb




